//
//  main.m
//  ADo_OpotionView
//
//  Created by 杜维欣 on 15/10/21.
//  Copyright © 2015年 杜维欣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
