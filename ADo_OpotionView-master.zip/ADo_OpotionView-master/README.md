# ADo_OpotionView
##自己摸索写了一个tableView内如果cell上有输入框  cell在编辑的情况下处理键盘高度的demo  
##以及与没有输入框的cell同时使用情况下cell重用问题
##
![ADo_OpotionView](http://ww4.sinaimg.cn/bmiddle/8e4407e9jw1ex8po2g6pjg20ac0j24qp.gif)
